<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <h1 class="pull-left">Create New Suratmasuk</h1>
        </div>
    </div>

    <?php echo $__env->make('core-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $suratmasuk=false ?>
    <?php if($klasifikasis): ?>
        <?php foreach($klasifikasis as $klasifikasi): ?>
            <?php $arr_klasifikasi[$klasifikasi->id] = $klasifikasi->nama_klasifikasi ?>    
        <?php endforeach; ?>
    <?php endif; ?>
    <?php $sifatsurat=false ?>    
    <?php if($sifatsurats): ?>
        <?php foreach($sifatsurats as $sifatsurat): ?>
            <?php $arr_sifatsurat[$sifatsurat->id] = $sifatsurat->nama_sifatsurat ?>
        <?php endforeach; ?>
    <?php endif; ?>
    <div class="row">
        <?php echo Form::open(['route' => 'admin.suratmasuks.store']); ?>


            <?php echo $__env->make('admin.suratmasuks.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>