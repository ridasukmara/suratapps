<!-- Dari Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('dari', 'Dari:'); ?>

    <?php echo Form::text('dari', null, ['class' => 'form-control']); ?>

</div>

<!-- No Suratmasuk Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_suratmasuk', 'No Suratmasuk:'); ?>    
    <?php echo Form::text('no_suratmasuk', null, ['class' => 'form-control']); ?>    
</div>

<!-- No Urut Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_urut', 'No Urut:'); ?>

    <?php echo Form::text('no_urut', null, ['class' => 'form-control']); ?>

</div>

<!-- Indeks Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('indeks', 'Indeks:'); ?>

    <?php echo Form::text('indeks', null   , ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Suratmasuk Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_suratmasuk', 'Tanggal Suratmasuk:'); ?>

    <?php if($suratmasuk): ?>
    <?php echo Form::date('tanggal_suratmasuk', \Carbon\Carbon::parse($suratmasuk->tanggalsuratmasuk) , ['class' => 'form-control']); ?>

    <?php else: ?>
    <?php echo Form::date('tanggal_suratmasuk', \Carbon\Carbon::now() , ['class' => 'form-control']); ?>

    <?php endif; ?>
    <p style="font-size:10px; color:red">  * Bulan/Tanggal/Tahun</p>
</div>

<!-- Tanggal Diteruskan Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_diteruskan', 'Tanggal Diteruskan:'); ?>

    <?php if($suratmasuk): ?>
    <?php echo Form::date('tanggal_diteruskan', \Carbon\Carbon::parse($suratmasuk->tanggalditeruskan), ['class' => 'form-control']); ?>

    <?php else: ?>
    <?php echo Form::date('tanggal_diteruskan', \Carbon\Carbon::now() , ['class' => 'form-control']); ?>

    <?php endif; ?>
    <p style="font-size:10px; color:red">  * Bulan/Tanggal/Tahun</p>
</div>

<!-- Perihal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('perihal', 'Perihal:'); ?>

    <?php echo Form::text('perihal', null, ['class' => 'form-control']); ?>

</div>

<!-- Id Klasifikasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_klasifikasi', 'Klasifikasi Surat:'); ?>

    <?php echo Form::select('id_klasifikasi', $arr_klasifikasi ,null, ['class' => 'form-control']); ?>

</div>


<!-- Id Klasifikasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_sifatsurat', 'Sifat Surat:'); ?>

    <?php echo Form::select('id_sifatsurat', $arr_sifatsurat ,null, ['class' => 'form-control']); ?>

</div>

<!-- Isi Ringkas Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('isi_ringkas', 'Isi Ringkas:'); ?>

    <?php echo Form::textarea('isi_ringkas', null, ['class' => 'form-control', 'rows' => '5']); ?>

</div>

<!-- Catatan Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('catatan', 'Catatan:'); ?>

    <?php echo Form::textarea('catatan', null, ['class' => 'form-control', 'rows' => '5']); ?>

</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.suratmasuks.index'); ?>" class="btn btn-default">Cancel</a>
</div>
