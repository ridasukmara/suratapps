<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $disposisi->id !!}</p>
</div>

<!-- Id Suratmasuk Field -->
<div class="form-group">
    {!! Form::label('id_suratmasuk', 'Id Suratmasuk:') !!}
    <p>{!! $disposisi->id_suratmasuk !!}</p>
</div>

<!-- Id Harap Field -->
<div class="form-group">
    {!! Form::label('id_harap', 'Id Harap:') !!}
    <p>{!! $disposisi->id_harap !!}</p>
</div>

<!-- Catatan Pengolah Field -->
<div class="form-group">
    {!! Form::label('catatan_pengolah', 'Catatan Pengolah:') !!}
    <p>{!! $disposisi->catatan_pengolah !!}</p>
</div>

<!-- Catatan Admintu Field -->
<div class="form-group">
    {!! Form::label('catatan_admintu', 'Catatan Admintu:') !!}
    <p>{!! $disposisi->catatan_admintu !!}</p>
</div>

<!-- Catatan Adminkepala Field -->
<div class="form-group">
    {!! Form::label('catatan_adminkepala', 'Catatan Adminkepala:') !!}
    <p>{!! $disposisi->catatan_adminkepala !!}</p>
</div>

<!-- Verifikasi Field -->
<div class="form-group">
    {!! Form::label('verifikasi', 'Verifikasi:') !!}
    <p>{!! $disposisi->verifikasi !!}</p>
</div>

<!-- Tanggal Verifikasi Field -->
<div class="form-group">
    {!! Form::label('tanggal_verifikasi', 'Tanggal Verifikasi:') !!}
    <p>{!! $disposisi->tanggal_verifikasi !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $disposisi->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $disposisi->updated_at !!}</p>
</div>

