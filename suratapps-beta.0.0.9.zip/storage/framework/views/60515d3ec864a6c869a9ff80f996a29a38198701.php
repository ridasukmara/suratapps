<table class="table table-responsive" id="suratmasuks-table">
    <thead>
        <th>Dari</th>
        <th>Klasifikasi Surat</th>
        <th>Indeks</th>
        <th>Perihal</th>
        <th>Isi Ringkas</th>
        <th>Tgl Masuk</th>
        <th>Catatan</th>
        <th colspan="4">Action</th>
    </thead>
    <tbody>
    <?php foreach($suratmasuks as $suratmasuk): ?>

        <tr>            
            <td><?php echo $suratmasuk->dari; ?></td>
            <td><?php echo $suratmasuk->klasifikasi->nama_klasifikasi; ?></td>
            <td><?php echo $suratmasuk->indeks; ?></td>
            <td><?php echo $suratmasuk->perihal; ?></td>
            <td><?php echo $suratmasuk->isi_ringkas; ?></td>            
            <td><?php echo $suratmasuk->tanggal_suratmasuk; ?></td>
            <td><?php echo $suratmasuk->catatan; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.suratmasuks.destroy', $suratmasuk->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.suratmasuks.show', [$suratmasuk->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.suratmasuks.edit', [$suratmasuk->id]); ?>" class='btn btn-warning btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    <a href="<?php echo route('admin.suratmasuks.disposisi', [$suratmasuk->id]); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-check"></i></a>
                     <a href="<?php echo route('admin.suratmasuks.lampiran', [$suratmasuk->id]); ?> " class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-file"></i></a>
                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>    
</table>
