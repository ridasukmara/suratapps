<table class="table table-responsive" id="jenissurats-table">
    <thead>
        <th>Kode Jenissurat</th>
        <th>Nama Jenissurat</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($jenissurats as $jenissurat): ?>
        <tr>
            <td><?php echo $jenissurat->kode_jenissurat; ?></td>
            <td><?php echo $jenissurat->nama_jenissurat; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.jenissurats.destroy', $jenissurat->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.jenissurats.show', [$jenissurat->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.jenissurats.edit', [$jenissurat->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
