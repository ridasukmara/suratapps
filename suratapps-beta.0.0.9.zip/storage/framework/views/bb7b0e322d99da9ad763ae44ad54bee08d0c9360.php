<table class="table table-responsive" id="agendasuratmasuks-table">
    <thead>
        <th>Id Suratmasuk</th>
        <th>Tanggal Diterima</th>
        <th>No Agenda</th>
        <th>Status</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($agendasuratmasuks as $agendasuratmasuk): ?>
        <tr>
            <td><?php echo $agendasuratmasuk->id_suratmasuk; ?></td>
            <td><?php echo $agendasuratmasuk->tanggal_diterima; ?></td>
            <td><?php echo $agendasuratmasuk->no_agenda; ?></td>
            <td><?php echo $agendasuratmasuk->status; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.agendasuratmasuks.destroy', $agendasuratmasuk->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.agendasuratmasuks.show', [$agendasuratmasuk->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.agendasuratmasuks.edit', [$agendasuratmasuk->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
