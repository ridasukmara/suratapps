<table class="table table-responsive" id="penggunas-table">
    <thead>
        <th>Nama Pegawai</th>
        <th>Jabatan</th>
        <th>Nip</th>
        <th>Hak Akses</th>
        <th>Foto</th>
        <th>Username</th>
        <th>Password</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($penggunas as $pengguna): ?>
        <tr>
            <td><?php echo $pengguna->nama_pegawai; ?></td>
            <td><?php echo $pengguna->jabatan; ?></td>
            <td><?php echo $pengguna->nip; ?></td>
            <td><?php echo $pengguna->hak_akses; ?></td>
            <td><?php echo $pengguna->foto; ?></td>
            <td><?php echo $pengguna->username; ?></td>
            <td><?php echo $pengguna->password; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.penggunas.destroy', $pengguna->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.penggunas.show', [$pengguna->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.penggunas.edit', [$pengguna->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
