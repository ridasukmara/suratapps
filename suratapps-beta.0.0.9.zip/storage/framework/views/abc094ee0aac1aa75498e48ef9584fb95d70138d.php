<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $agendasuratmasuk->id; ?></p>
</div>

<!-- Id Suratmasuk Field -->
<div class="form-group">
    <?php echo Form::label('id_suratmasuk', 'Id Suratmasuk:'); ?>

    <p><?php echo $agendasuratmasuk->id_suratmasuk; ?></p>
</div>

<!-- Tanggal Diterima Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_diterima', 'Tanggal Diterima:'); ?>

    <p><?php echo $agendasuratmasuk->tanggal_diterima; ?></p>
</div>

<!-- No Agenda Field -->
<div class="form-group">
    <?php echo Form::label('no_agenda', 'No Agenda:'); ?>

    <p><?php echo $agendasuratmasuk->no_agenda; ?></p>
</div>

<!-- Status Field -->
<div class="form-group">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo $agendasuratmasuk->status; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $agendasuratmasuk->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $agendasuratmasuk->updated_at; ?></p>
</div>

