<!-- Kode lampiran Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('lampiran', 'Kode lampiran:'); ?>

    <?php echo Form::file('lampiran', null, ['class' => 'form-control']); ?>

    <?php echo Form::hidden('id_suratmasuk', $suratmasuk->id); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.suratmasuks.lampiran', ['id'=> $suratmasuk->id]); ?>" class="btn btn-default">Cancel</a>
</div>
