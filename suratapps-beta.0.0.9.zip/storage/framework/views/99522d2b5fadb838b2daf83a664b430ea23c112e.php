<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $klasifikasi->id; ?></p>
</div>

<!-- Kode Klasifikasi Field -->
<div class="form-group">
    <?php echo Form::label('kode_klasifikasi', 'Kode Klasifikasi:'); ?>

    <p><?php echo $klasifikasi->kode_klasifikasi; ?></p>
</div>

<!-- Nama Klasifikasi Field -->
<div class="form-group">
    <?php echo Form::label('nama_klasifikasi', 'Nama Klasifikasi:'); ?>

    <p><?php echo $klasifikasi->nama_klasifikasi; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $klasifikasi->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $klasifikasi->updated_at; ?></p>
</div>

