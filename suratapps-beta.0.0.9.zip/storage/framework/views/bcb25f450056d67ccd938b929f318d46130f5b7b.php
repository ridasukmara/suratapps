<table class="table table-responsive" id="klasifikasis-table">
    <thead>
        <th>Kode Klasifikasi</th>
        <th>Nama Klasifikasi</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($klasifikasis as $klasifikasi): ?>
        <tr>
            <td><?php echo $klasifikasi->kode_klasifikasi; ?></td>
            <td><?php echo $klasifikasi->nama_klasifikasi; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.klasifikasis.destroy', $klasifikasi->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.klasifikasis.show', [$klasifikasi->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.klasifikasis.edit', [$klasifikasi->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
