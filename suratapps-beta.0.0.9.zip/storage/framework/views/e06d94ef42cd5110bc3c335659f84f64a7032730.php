<table class="table table-responsive" id="pegawais-table">
    <thead>
        <th>Nama Pegawai</th>
        <th>Jabatan</th>
        <th>Nip</th>
        <th>Hak Akses</th>
        <th>Foto</th>
        <th>Username</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($pegawais as $pegawai): ?>
        <tr>
            <td><?php echo $pegawai->nama_pegawai; ?></td>
            <td><?php echo $pegawai->jabatan; ?></td>
            <td><?php echo $pegawai->nip; ?></td>
            <td><?php echo $pegawai->hak_akses; ?></td>
            <?php if($pegawai->foto != ''): ?>
            <td><img width="20" height="20" src="<?php echo asset('foto/'); ?>/<?php echo $pegawai->foto; ?>"></td>
            <?php else: ?>
            <td><img width="20" height="20" src="<?php echo asset('foto/default.png'); ?>"></td>
            <?php endif; ?>
            <td><?php echo $pegawai->username; ?></td>            
            <td>
                <?php echo Form::open(['route' => ['admin.pegawais.destroy', $pegawai->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.pegawais.show', [$pegawai->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.pegawais.edit', [$pegawai->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
