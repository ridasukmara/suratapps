<!-- Id Suratmasuk Field -->
<!-- <div class="form-group col-sm-6">
    <?php echo Form::label('id_suratmasuk', 'Id Suratmasuk:'); ?>

    <?php echo Form::text('id_suratmasuk', null, ['class' => 'form-control', 'readonly'=>'true']); ?>

</div> -->

<!-- Id Harap Field -->
<!-- <div class="form-group col-sm-6">
    <?php echo Form::label('id_harap', 'Id Harap:'); ?>

    <?php echo Form::text('id_harap', null, ['class' => 'form-control']); ?>

</div> -->

<?php echo Form::hidden('id_suratmasuk', $suratmasuk->id); ?>


<?php if( (auth()->guard('pegawais')->user()) && (auth()->guard('pegawais')->user()->hak_akses== "1") ): ?>

<!-- Catatan Pengolah Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('catatan_pengolah', 'Catatan Pengolah:'); ?>

    <?php echo Form::textarea('catatan_pengolah', null, ['class' => 'form-control', 'rows' => '5']); ?>

</div>

<?php elseif((auth()->guard('pegawais')->user()) && (auth()->guard('pegawais')->user()->hak_akses== "2") ): ?>

<!-- Catatan Admintu Field -->`
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('catatan_admintu', 'Catatan Admintu:'); ?>

    <?php echo Form::textarea('catatan_admintu', null, ['class' => 'form-control', 'rows' => '5' , 'readonly' => true]); ?>

</div>
<?php elseif( (auth()->guard('pegawais')->user()) && (auth()->guard('pegawais')->user()->hak_akses== "3") ): ?>

<!-- Catatan Adminkepala Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('catatan_adminkepala', 'Catatan Adminkepala:'); ?>

    <?php echo Form::textarea('catatan_adminkepala', null, ['class' => 'form-control', 'rows' => '5', 'readonly' => true]); ?>

</div>


<!-- Verifikasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('verifikasi', 'Verifikasi:'); ?>

    <?php echo Form::text('verifikasi', null, ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Verifikasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_verifikasi', 'Tanggal Verifikasi:'); ?>

    <?php echo Form::date('tanggal_verifikasi', Carbon\Carbon::now(), ['class' => 'form-control']); ?>    
</div>

<?php endif; ?>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.suratmasuks.disposisi', [$suratmasuk->id, $disposisi->id]); ?>" class="btn btn-default">Cancel</a>
</div>
