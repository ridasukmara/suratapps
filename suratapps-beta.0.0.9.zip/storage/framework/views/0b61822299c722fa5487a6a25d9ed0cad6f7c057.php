<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $suratmasuk->id; ?></p>
</div>

<!-- Id Klasifikasi Field -->
<div class="form-group">
    <?php echo Form::label('id_klasifikasi', 'Id Klasifikasi:'); ?>

    <p><?php echo $suratmasuk->id_klasifikasi; ?></p>
</div>

<!-- Id Pegawai Field -->
<div class="form-group">
    <?php echo Form::label('id_pegawai', 'Id Pegawai:'); ?>

    <p><?php echo $suratmasuk->id_pegawai; ?></p>
</div>

<!-- Id Disposisi Field -->
<div class="form-group">
    <?php echo Form::label('id_disposisi', 'Id Disposisi:'); ?>

    <p><?php echo $suratmasuk->id_disposisi; ?></p>
</div>

<!-- Indeks Field -->
<div class="form-group">
    <?php echo Form::label('indeks', 'Indeks:'); ?>

    <p><?php echo $suratmasuk->indeks; ?></p>
</div>

<!-- No Urut Field -->
<div class="form-group">
    <?php echo Form::label('no_urut', 'No Urut:'); ?>

    <p><?php echo $suratmasuk->no_urut; ?></p>
</div>

<!-- Perihal Field -->
<div class="form-group">
    <?php echo Form::label('perihal', 'Perihal:'); ?>

    <p><?php echo $suratmasuk->perihal; ?></p>
</div>

<!-- Isi Ringkas Field -->
<div class="form-group">
    <?php echo Form::label('isi_ringkas', 'Isi Ringkas:'); ?>

    <p><?php echo $suratmasuk->isi_ringkas; ?></p>
</div>

<!-- Dari Field -->
<div class="form-group">
    <?php echo Form::label('dari', 'Dari:'); ?>

    <p><?php echo $suratmasuk->dari; ?></p>
</div>

<!-- Tanggal Suratmasuk Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_suratmasuk', 'Tanggal Suratmasuk:'); ?>

    <p><?php echo $suratmasuk->tanggal_suratmasuk; ?></p>
</div>

<!-- No Suratmasuk Field -->
<div class="form-group">
    <?php echo Form::label('no_suratmasuk', 'No Suratmasuk:'); ?>

    <p><?php echo $suratmasuk->no_suratmasuk; ?></p>
</div>

<!-- Tanggal Diteruskan Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_diteruskan', 'Tanggal Diteruskan:'); ?>

    <p><?php echo $suratmasuk->tanggal_diteruskan; ?></p>
</div>

<!-- Catatan Field -->
<div class="form-group">
    <?php echo Form::label('catatan', 'Catatan:'); ?>

    <p><?php echo $suratmasuk->catatan; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $suratmasuk->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $suratmasuk->updated_at; ?></p>
</div>

