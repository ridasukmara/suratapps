<table class="table table-responsive" id="lampirans-table">
    <thead>
        <th>ID Lampiran</th>
        <th>Lampiran</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>

    <?php foreach($lampirans as $lampiran): ?>
        <tr>
            <td><?php echo $lampiran->id; ?></td>
            <td><?php echo $lampiran->lampiran; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.suratmasuks.lampiran.destroy', $lampiran->id, $suratmasuk->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.suratmasuks.lampiran.show', [$suratmasuk->id,  $lampiran->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>                   
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
