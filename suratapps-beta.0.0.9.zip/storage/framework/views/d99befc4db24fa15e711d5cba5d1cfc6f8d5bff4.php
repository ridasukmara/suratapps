<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Lampiran:'); ?>

    <p><?php echo $lampiran->lampiran; ?></p>
</div>
