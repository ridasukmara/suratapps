<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-sm-12">
                <h1 class="pull-left">Edit Suratmasuk</h1>
            </div>
        </div>

        <?php echo $__env->make('core-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php foreach($sifatsurats as $sifatsurat): ?>
            <?php $arr_sifatsurat[$sifatsurat->id] = $sifatsurat->nama_sifatsurat ?>
        <?php endforeach; ?>
        <?php foreach($klasifikasis as $klasifikasi): ?>
            <?php $arr_klasifikasi[$klasifikasi->id] = $klasifikasi->nama_klasifikasi ?>
        <?php endforeach; ?>

        <div class="row">
            <?php echo Form::model($suratmasuk, ['route' => ['admin.suratmasuks.update', $suratmasuk->id], 'method' => 'patch']); ?>


            <?php echo $__env->make('admin.suratmasuks.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::close(); ?>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>