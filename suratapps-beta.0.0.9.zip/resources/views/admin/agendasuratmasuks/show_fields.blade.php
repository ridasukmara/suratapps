<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $agendasuratmasuk->id !!}</p>
</div>

<!-- Id Suratmasuk Field -->
<div class="form-group">
    {!! Form::label('id_suratmasuk', 'Id Suratmasuk:') !!}
    <p>{!! $agendasuratmasuk->id_suratmasuk !!}</p>
</div>

<!-- Tanggal Diterima Field -->
<div class="form-group">
    {!! Form::label('tanggal_diterima', 'Tanggal Diterima:') !!}
    <p>{!! $agendasuratmasuk->tanggal_diterima !!}</p>
</div>

<!-- No Agenda Field -->
<div class="form-group">
    {!! Form::label('no_agenda', 'No Agenda:') !!}
    <p>{!! $agendasuratmasuk->no_agenda !!}</p>
</div>

<!-- Status Field -->
<div class="form-group">
    {!! Form::label('status', 'Status:') !!}
    <p>{!! $agendasuratmasuk->status !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $agendasuratmasuk->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $agendasuratmasuk->updated_at !!}</p>
</div>

