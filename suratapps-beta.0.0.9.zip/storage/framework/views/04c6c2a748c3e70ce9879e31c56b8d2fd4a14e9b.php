<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $sifatsurat->id; ?></p>
</div>

<!-- Nama Sifatsurat Field -->
<div class="form-group">
    <?php echo Form::label('nama_sifatsurat', 'Nama Sifatsurat:'); ?>

    <p><?php echo $sifatsurat->nama_sifatsurat; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $sifatsurat->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $sifatsurat->updated_at; ?></p>
</div>

