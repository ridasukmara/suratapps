<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $jenissurat->id; ?></p>
</div>

<!-- Kode Jenis Field -->
<div class="form-group">
    <?php echo Form::label('kode_jenis', 'Kode Jenis:'); ?>

    <p><?php echo $jenissurat->kode_jenis; ?></p>
</div>

<!-- Nama Jenis Field -->
<div class="form-group">
    <?php echo Form::label('nama_jenis', 'Nama Jenis:'); ?>

    <p><?php echo $jenissurat->nama_jenis; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $jenissurat->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $jenissurat->updated_at; ?></p>
</div>

