<table class="table table-responsive" id="haraps-table">
    <thead>
        <th>Nama Harap</th>
        <th colspan="3">Action</th>
    </thead>
    <tbody>
    <?php foreach($haraps as $harap): ?>
        <tr>
            <td><?php echo $harap->nama_harap; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.haraps.destroy', $harap->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.haraps.show', [$harap->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.haraps.edit', [$harap->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
